# -*- coding: utf-8 -*-
from threading import Thread, Event
import logging
import atexit
import signal


class Watcher(Thread):
    def __init__(self, threads, event:Event, logger=None):
        super().__init__(name="Watcher")
        self._threads = threads
        self._event = event
        self._logger = logger or logging
        self._exit_code = None
        atexit.register(self.stop)
        signal.signal(signal.SIGINT, self.stop)
        signal.signal(signal.SIGTERM, self.stop)

    @property
    def exit_code(self):
        return self._exit_code

    def run(self):
        self._logger.info("Starting")
        self._event.wait()
        self._logger.info("Exiting...")
        for t in self._threads:
            logging.debug('Stopping %s...' % t.name)
            t.stop()
            t.join()
        self._logger.info("Done")
        self._exit_code = 1

    def stop(self, *args, **kwargs):
        self._event.set()
        self._exit_code = 0
