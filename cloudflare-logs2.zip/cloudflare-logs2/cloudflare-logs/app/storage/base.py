# -*- coding: utf-8 -*-
from queue import Queue
from threading import Thread, Event
import logging
__all_ = [
    'BaseStorageAdapter'
]


class BaseStorageAdapter(Thread):
    def __init__(self, queue:Queue, stop_event:Event, logger=None, name=None):
        Thread.__init__(self, name=name)
        self._queue = queue
        self._stop_event = stop_event
        self._logger = logger or logging
        self._is_running=True

    def run(self):
        raise NotImplemented

    def stop(self):
        self._is_running = False
