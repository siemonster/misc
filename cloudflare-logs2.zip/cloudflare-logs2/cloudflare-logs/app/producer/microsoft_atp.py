# -*- coding: utf-8 -*-
from msrestazure.azure_active_directory import AADTokenCredentials
from queue import Queue, Empty
from threading import Thread, Event
from traceback import format_exc
import adal
import logging
import os
import requests
import time


class MicrosoftATP(object):
    def __init__(self, tenant=None, client_id=None, secret=None, region='us'):
        self._endpoint = "https://wdatp-alertexporter-%s.windows.com/api/alerts" % region
        self._tenant = tenant or os.environ['AZURE_TENANT_ID']
        self._client_id = client_id or os.environ['AZURE_CLIENT_ID']
        self._client_secret = secret or os.environ['AZURE_CLIENT_SECRET']
        self._session = requests.Session()
        self.authenticate_client_key()

    def authenticate_client_key(self):
        """
        Authenticate using service principal w/ key.
        """
        authority_host_uri = 'https://login.microsoftonline.com'
        authority_uri = authority_host_uri + '/' + self._tenant
        resource_uri = 'https://graph.windows.net'

        context = adal.AuthenticationContext(authority_uri, api_version=None)
        mgmt_token = context.acquire_token_with_client_credentials(resource_uri, self._client_id, self._client_secret)
        credentials = AADTokenCredentials(mgmt_token, self._client_id)
        self._session.headers.update( {
            "Authorization": "Bearer %s" % credentials.token['access_token']
        })

    def get_alerts(self, start_time, end_time):
        max_retries = 3
        r_count = 0
        while r_count <= max_retries:
            res = self._session.get("%s?sinceTimeUtc=%s&untilTimeUtc=%s" % (self._endpoint, start_time, end_time))
            r_count += 1
            if res.status_code == 401:
                self.authenticate_client_key()
                if r_count > max_retries:
                    return {'code': res.status_code, 'message': res.text}
                continue
            if res.status_code == 200:
                try:
                    data = res.json()
                except:
                    print("error decoding json string: %s" % res.text)
                    raise
                return data
            if 400 <= res.status_code <= 599:
                return {'code': res.status_code, 'message': res.text}


class MicrosoftATPWorker(Thread):
    def __init__(self, cf:MicrosoftATP, time_interval_q: Queue, out_q: Queue, stop_event:Event, circuit_breaker, circuit_breaker_timeout=60, logger=None, name=None):
        Thread.__init__(self, name=name)
        self._time_interval_q = time_interval_q
        self._out_q = out_q
        self._logger = logger or logging
        self._is_running=True
        self._stop_event = stop_event
        self._circuit_breaker = circuit_breaker
        self._circuit_breaker_timeout = circuit_breaker_timeout
        self._cf = cf

    def run(self):
        self._logger.debug("Starting")
        while self._is_running:
            self._circuit_breaker.wait(timeout=self._circuit_breaker_timeout)
            self._circuit_breaker.set()

            try:
                t_interval = self._time_interval_q.get(timeout=3)
            except Empty:
                continue

            self._logger.debug(t_interval)
            try:
                res = self._cf.get_alerts(t_interval.start_iso8601, t_interval.end_iso8601)
                if isinstance(res, list):
                    for el in res:
                        self._out_q.put(el)
                elif isinstance(res, dict):
                    if res.get('code') == 429:
                        # back to queue
                        self._time_interval_q.put(t_interval)
                        self._logger.warning('Rate limits: exceeded')
                        self._circuit_breaker.clear()
                    if 400 <= res.get('code', 500) <= 499:
                        self._logger.error(res)
                        self._stop_event.set()
                        break
                    if 500 <= res.get('code', 500) <= 599:
                        # back to queue
                        self._time_interval_q.put(t_interval)
                        self._logger.warning(res)
                        self._circuit_breaker.clear()
                    if 600 <= res.get('code', 500):
                        self._logger.error(res)
                        self._stop_event.set()
                        break
                else:
                    self._logger.debug(res)
            except Exception as e:
                self._logger.error("%s" % format_exc())
                self._stop_event.set()
                break
            self._time_interval_q.task_done()

    def stop(self):
        self._is_running = False


class MicrosoftATPProducer(Thread):
    def __init__(self, env, time_interval_q: Queue, out_q: Queue, stop_event:Event, num_workers: int = 5, logger=None):
        Thread.__init__(self, name="MicrosoftATPProducer")
        self._is_running=True
        self._time_interval_q = time_interval_q
        self._out_q = out_q
        self._stop_event = stop_event
        self._num_workers = num_workers
        self._logger = logger or logging
        self._workers = []
        self._circuit_breaker=Event()
        self._circuit_breaker.set()
        self._cf = MicrosoftATP()

    def run(self):
        self._logger.info("Starting (%s workers)" % self._num_workers)
        for w in range(self._num_workers):
            inst = MicrosoftATPWorker(
                cf=self._cf, time_interval_q=self._time_interval_q, stop_event=self._stop_event,
                circuit_breaker=self._circuit_breaker, out_q=self._out_q,
                logger=self._logger, name="MicrosoftATPWorker-%s" % w)
            inst.start()
            self._workers.append(inst)
            while self._is_running:
                time.sleep(1)

    def stop(self):
        for w in self._workers:
            if w.is_alive():
                self._logger.debug("Stopping %s" % w.name)
                w.stop()
                w.join()
        self._is_running = False
