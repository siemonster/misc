# -*- coding: utf-8 -*-
from queue import Queue, Empty
from threading import Thread, Event
from traceback import format_exc
import logging
import CloudFlare
import time


class CloudFlareWorker(Thread):
    def __init__(self, zone_id, cf:CloudFlare, time_interval_q: Queue, out_q: Queue, stop_event:Event, circuit_breaker, circuit_breaker_timeout=60, logger=None, name=None, cf_additional_fields=None):
        Thread.__init__(self, name=name)
        self._time_interval_q = time_interval_q
        self._out_q = out_q
        self._logger = logger or logging
        self._is_running=True
        self._zone_id = zone_id
        self._stop_event = stop_event
        self._circuit_breaker = circuit_breaker
        self._circuit_breaker_timeout = circuit_breaker_timeout
        self._cf = cf
        self._cf_additional_fields = cf_additional_fields

    def run(self):
        def get_status_code(res):
            if isinstance(res, list):
                return 200
            if isinstance(res, dict):
                if res.get('code'):
                    return res.get('code')
                if 'errors' in res and isinstance(res['errors'], list):
                    return res['errors'][0].get('code', 0)
            return 0

        self._logger.debug("Starting")
        while self._is_running:
            self._circuit_breaker.wait(timeout=self._circuit_breaker_timeout)
            self._circuit_breaker.set()

            try:
                t_interval = self._time_interval_q.get(timeout=3)
            except Empty:
                continue

            self._logger.debug(t_interval)
            cf_params = {'start': t_interval.start_stamp, 'end': t_interval.end_stamp}
            if self._cf_additional_fields:
                cf_params = {**cf_params, **{'fields': ','.join(self._cf_additional_fields)}}
            try:
                res = self._cf.zones.logs.received.get(
                    self._zone_id, params=cf_params)
                status_code = get_status_code(res)
                if isinstance(res, list):
                    for el in res:
                        self._out_q.put({**el, 'zone_id':self._zone_id})
                elif isinstance(res, dict):
                    if status_code == 429:
                        # back to queue
                        self._time_interval_q.put(t_interval)
                        self._logger.warning('Rate limits: exceeded')
                        self._circuit_breaker.clear()
                    if 400 <= status_code <= 499:
                        self._logger.error(res)
                        self._stop_event.set()
                        break
                    if 500 <= status_code <= 599:
                        # back to queue
                        self._time_interval_q.put(t_interval)
                        self._logger.warning(res)
                        self._circuit_breaker.clear()
                    if 600 <= status_code:
                        # non HTTP error
                        self._logger.error(res)
                        self._stop_event.set()
                        break
                else:
                    self._logger.debug(res)
            except CloudFlare.exceptions.CloudFlareAPIError as e:
                # back to queue
                self._time_interval_q.put(t_interval)
                self._logger.warning("%s" % format_exc())
            except Exception as e:
                self._logger.error("%s" % format_exc())
                self._stop_event.set()
                break
            self._time_interval_q.task_done()

    def stop(self):
        self._is_running = False


class CloudFlareProducer(Thread):
    def __init__(self, env, time_interval_q: Queue, out_q: Queue, stop_event:Event, num_workers: int = 5, logger=None):
        Thread.__init__(self, name="CloudFlareProducer")
        self._is_running=True
        self._env = env
        self._zone_id = env['CF_ZONE_ID']
        self._time_interval_q = time_interval_q
        self._out_q = out_q
        self._stop_event = stop_event
        self._num_workers = num_workers
        self._logger = logger or logging
        self._workers = []
        self._circuit_breaker=Event()
        self._circuit_breaker.set()
        self._cf = CloudFlare.CloudFlare(use_sessions=True)

    def run(self):
        self._logger.info("Starting (%s workers)" % self._num_workers)
        for w in range(self._num_workers):
            inst = CloudFlareWorker(
                self._zone_id, cf=self._cf, time_interval_q=self._time_interval_q, stop_event=self._stop_event,
                circuit_breaker=self._circuit_breaker, out_q=self._out_q,
                logger=self._logger, name="CloudFlareWorker-%s" % w,
                cf_additional_fields=self._env['CF_ADDITIONAL_FIELDS']
            )
            inst.start()
            self._workers.append(inst)
        while self._is_running:
            time.sleep(1)

    def stop(self):
        for w in self._workers:
            if w.is_alive():
                self._logger.debug("Stopping %s" % w.name)
                w.stop()
                w.join()
        self._is_running = False
