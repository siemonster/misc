# -*- coding: utf-8 -*-
import os


class Environment(object):
    def __init__(self, schema=None):
        self._schema = schema or {}

    def _validate(self, k):
        def check_type(val):
            if not self._schema[k].get('type'):
                return val
            return self._schema[k]['type'](val)

        if self._schema[k].get('required'):
            return check_type(
                os.environ.get(k, self._schema[k].get('default')) if "default" in self._schema[k] else os.environ[k]
            )
        return check_type(
            os.environ.get(k, self._schema[k].get('default')) if "default" in self._schema[k] else os.environ.get(k, '')
        )

    def _get_description(self, k):
        if self._schema[k].get('description'):
            return self._schema[k].get('description')
        return ""

    def validate(self):
        fail=False
        for key in self._schema.keys():
            try:
                self._validate(key)
            except KeyError as e:
                print("Environment variable not found: %s %s" % (e, self._get_description(key)))
                fail = True
        if fail:
            raise RuntimeError('Validation failed')
        return self

    def __getitem__(self, name):
        if name in self._schema:
            return self._validate(name)
        else:
            return os.environ[name]
