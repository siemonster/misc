#!/bin/bash

set -e

host="es-master"
ELASTIC_USER=${ELASTIC_USER:-elastic}
ELASTIC_PWD=${ELASTIC_PWD:-changeme}
SEARCHGUARD_COOKIE=${SEARCHGUARD_COOKIE:-4fjNPloEVvrVj28BsVh3jI8t3pmv7Qg6}
WAZUH_API_PWD=${WAZUH_API_PWD:-changeme}
WAZUH_API_PASSWORD_BASE64=$(echo -n $WAZUH_API_PWD | base64)
shift
cmd="kibana"

cat <<EOF >/usr/share/kibana/config/kibana.yml
server.port: 5601
server.host: "0.0.0.0"
elasticsearch.url: "https://${ELASTIC_USER}:${ELASTIC_PWD}@${host}:9200"
elasticsearch.username: "${ELASTIC_USER}"
elasticsearch.password: "${ELASTIC_PWD}"
elasticsearch.ssl.verificationMode: "certificate"
searchguard.basicauth.enabled: false
#xpack.grokdebugger.enabled: false
#xpack.graph.enabled: false
#xpack.ml.enabled: false
#xpack.monitoring.enabled: false
#xpack.monitoring.report_stats: false
#xpack.reporting.enabled: false
#xpack.security.enabled: false
searchguard.cookie.password: "${SEARCHGUARD_COOKIE}"
elasticsearch.ssl.certificateAuthorities: /elasticsearch/config/searchguard/ssl/ca/root-ca.pem
elasticsearch.requestHeadersWhitelist: [ "authorization", "x-forwarded-for", "x-forwarded-by", "x-proxy-user", "x-proxy-roles" ]
EOF

until [ "$(curl -k -s 'https://elastic:'"${ELASTIC_PWD}"'@'"$host"':9200/_cluster/health' | grep "green")" ]; do
  >&2 echo "Waiting for cluster"
  sleep 5
done

>&2 echo "Elastic is up - executing command"

# Create 411 index
cat /usr/share/kibana/config/foo-index-create.json | curl -k -XPUT "https://${ELASTIC_USER}:${ELASTIC_PWD}@$host:9200/_template/411_alerts_wildcard" -H 'Content-Type: application/json' -d @-
sleep 5
#Insert default templates
cat /usr/share/kibana/config/wazuh-elastic6-template-alerts.json | curl -k -XPUT "https://${ELASTIC_USER}:${ELASTIC_PWD}@$host:9200/_template/wazuh" -H 'Content-Type: application/json' -d @-

#sleep 5
#Insert default templates
#cat /usr/share/kibana/config/wazuh-elastic6-template-monitoring.json | curl -k -XPUT "https://${ELASTIC_USER}:${ELASTIC_PWD}@$host:9200/_template/wazuh-agent" -H 'Content-Type: application/json' -d @-

#Insert sample alert:
#sleep 5
#cat /usr/share/kibana/config/alert_sample.json | curl -k -XPUT "https://${ELASTIC_USER}:${ELASTIC_PWD}@$host:9200/wazuh-alerts-3.x-"`date +%Y.%m.%d`"/wazuh/sample" -H 'Content-Type: application/json' -d @-

sleep 5
echo "Setting API credentials into Wazuh APP"
CONFIG_CODE=$(curl -k -s -o /dev/null -w "%{http_code}" -XGET https://${ELASTIC_USER}:${ELASTIC_PWD}@$host:9200/.wazuh/wazuh-configuration/1513629884013)
if [ "x$CONFIG_CODE" = "x404" ]; then
  curl -k -s -XPOST https://${ELASTIC_USER}:${ELASTIC_PWD}@$host:9200/.wazuh/wazuh-configuration/1513629884013 -H 'Content-Type: application/json' -d'
    {
      "api_user": "siemonster",
      "api_password": "'$WAZUH_API_PASSWORD_BASE64'",
      "url": "http://wazuh",
      "api_port": "55000",
      "insecure": "true",
      "component": "API",
      "cluster_info": {
        "manager": "wazuh-manager",
        "cluster": "Disabled",
        "status": "disabled"
       },
      "extensions": {
        "oscap": true,
        "audit": true,
        "pci": true,
        "aws": true,
        "virustotal": true,
        "gdpr": true
      }
    }
    ' > /dev/null
else
  echo "Wazuh APP already configured"
fi

sleep 5

exec $cmd

